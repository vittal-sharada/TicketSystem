import org.junit.Assert;
import org.junit.Test;


public class useNumSeatsServiceTest {
      private static final String validURL="http://localhost:4567/numSeatsAvailable/"; // print "all ok"
      private static final String notExistURL="http://localhost:4567/numSeatsAvailabledkad/"; //print http code 404
      private static final String invalidURL= "Abc";
    @Test(expected = RuntimeException.class)
    public final void checkURLFormat() {
        useNumSeatsService.checkSeats(invalidURL);
    }

    @Test(expected = RuntimeException.class)
    public final void httpCode() {
        useNumSeatsService.checkSeats(notExistURL);
    }

    @Test
    public final void validCall() {
        useNumSeatsService.checkSeats(validURL);
        Assert.assertTrue(true);
    }
}