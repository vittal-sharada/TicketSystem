public class Main {
    public static void main(String[] args) {
        try {
            numSeatsService n = new numSeatsService();
            System.out.println("Num seat service started:" + n.numSeatsAvailable());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}


