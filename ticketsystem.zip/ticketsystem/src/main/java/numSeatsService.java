import spark.Request;
import spark.Response;
import spark.Route;

import static spark.Spark.get;

public class numSeatsService {
    public static int numSeatsAvailable() throws Exception {

        get("/numSeatsAvailable/", new Route() {
            @Override
            public Object handle(Request request, Response response) {
                return "2";
            }
        });
        return 0;


    }
}