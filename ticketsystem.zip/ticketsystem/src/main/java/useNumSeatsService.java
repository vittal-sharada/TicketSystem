import org.testng.annotations.Test;
import spark.utils.ResourceUtils;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class useNumSeatsService {
    private static final String ACCEPT = "application/json";

    public static final void checkSeats(final String a) {
        try {

            if( !ResourceUtils.isUrl(a)) {
                throw new RuntimeException("URL invalid");
            }
            else {
                URL url = new URL(a);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", ACCEPT);

                if (conn.getResponseCode() != 200) {
                    throw new RuntimeException("HTTP error code:" + conn.getResponseCode());
                } else {
                    System.out.println("all ok");
                }
                conn.disconnect();
            }
        }
        catch (MalformedURLException e) {
            System.out.println(e);
        }
        catch ( Exception e) {
            System.out.println(e);
        }
    }
}


