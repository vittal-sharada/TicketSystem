$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/features/ticketsystem/seatReserve.feature");
formatter.feature({
  "line": 1,
  "name": "",
  "description": "  Seat Reserve",
  "id": "",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "",
  "description": "",
  "id": ";",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "the system knows the seat holdid is 1",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "the system knows the customer email as \"svittal@abc.com\"",
  "keyword": "And "
});
formatter.step({
  "line": 6,
  "name": "customer calls /GET /reserveSeat",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "the system returns reservation confirmation id",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 36
    }
  ],
  "location": "seatReserveSteps.theSystemKnowsTheSeatHoldidIs(int)"
});
formatter.result({
  "duration": 335700379,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "svittal@abc.com",
      "offset": 40
    }
  ],
  "location": "seatReserveSteps.theSystemKnowsTheCustomerEmailAs(String)"
});
formatter.result({
  "duration": 4553510,
  "status": "passed"
});
formatter.match({
  "location": "seatReserveSteps.customer_calls_GET_reserveSeat()"
});
formatter.result({
  "duration": 7959270,
  "status": "passed"
});
formatter.match({
  "location": "seatReserveSteps.theSystemReturnsReservationConfirmationIdAs()"
});
formatter.result({
  "duration": 11229371,
  "status": "passed"
});
});