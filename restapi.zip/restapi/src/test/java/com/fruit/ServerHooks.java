package com.fruit;

public class ServerHooks {
}
