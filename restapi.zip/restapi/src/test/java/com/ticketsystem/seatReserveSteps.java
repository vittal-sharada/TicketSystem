package com.ticketsystem;


import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import implement.ticketsystem.ReserveSeats;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.*;


public class seatReserveSteps {
    ReserveSeats rs = new ReserveSeats();

    @Given("^the system knows the seat holdid is (\\d+)$")
    public void theSystemKnowsTheSeatHoldidIs(int arg0)  {
        rs.setHoldid(arg0);

    }

    @And("^the system knows the customer email as \"([^\"]*)\"$")
    public void theSystemKnowsTheCustomerEmailAs(String arg0)  {
        rs.setReserveEmail(arg0);
    }

    @When("^customer calls /GET /reserveSeat$")
    public void customer_calls_GET_reserveSeat()  {
        System.out.println("get reserve logic");
    }


    @Then("^the system returns reservation confirmation id$")
    public void theSystemReturnsReservationConfirmationIdAs()  {
      String resId = rs.getResConfirmation();
       // String resId = null ;
        System.out.println(resId);
       //assertNull("reservation id is null", rs);
       assertFalse(resId.equalsIgnoreCase(null));

    }

}
