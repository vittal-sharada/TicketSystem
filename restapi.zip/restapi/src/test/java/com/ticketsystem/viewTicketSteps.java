package com.ticketsystem;

import cucumber.api.java.en.And;
import implement.ticketsystem.Tickets;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;


public class viewTicketSteps {

    Tickets ticket = new Tickets();

    @Given("^the system knows the (\\d+) tickets at the venue$")
    public void theSystemKnowsTheMaxTicketsAtTheVenue(int max)  {
        ticket.setMax(max);;
        assertTrue(max>=0 && max<=298);

    }
    @And("^the (\\d+) hold tickets at the venue$")
    public void theHoldTicketsAtTheVenue(int hold) {
        // Write code here that turns the phrase above into concrete actions
        ticket.setHold(hold);
        assertTrue(hold>=0 && hold<=298);
    }

    @And("^the (\\d+) reserved tickets at the venue$")
    public void theReservedTicketsAtTheVenue( int reserve) {
        // Write code here that turns the phrase above into concrete actions
       ticket.setReserve(reserve);
       assertTrue(reserve>=0 && reserve<=298);
    }

    @When("^the client requests GET /viewtickets$")
    public void theClientRequestsGETViewtickets()  {
        // Write code here that turns the phrase above into concrete actions
       System.out.println("get tickets logic");
    }

    @Then("^the (\\d+) should be the maximum number of tickets that are neither held nor reserved$")
    public void theResponseShouldBeTheMaximumNumberOfTicketsThatAreNeitherHeldNorReserved(int response)  {
       int resp = ticket.viewseats();
       ticket.setResponse(response);
       //assertTrue(resp >=0 && resp <=289);
        assertEquals(response,resp);

    }

}
