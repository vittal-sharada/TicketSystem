package com.ticketsystem;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import implement.ticketsystem.HoldSeats;

public class seatHoldSteps {
    HoldSeats h = new HoldSeats();

    @Given("^The system knows the email as \"([^\"]*)\"$")
    public void theSystemKnowsTheEmailAs(String arg0)  {
        h.setEmail(arg0);
    }

    @When("^user selects (\\d+) seat$")
    public void userSelectsSeat(int arg0)  {
       h.setSelectSeat(arg0);
    }

    @Then("^The system returns seat object for the user$")
    public void theSystemReturnsSeatObjectForTheUser()  {
        HoldSeats j = h.setHold();

        System.out.println(j.getEmail());
        System.out.println(j.getSelectSeat());
    }

    @When("^the client requests POST /HoldTickets$")
    public void theClientRequestsPOSTHoldTickets()  {
        System.out.println("post hold logic");
    }


}
