package implementation.fruit;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.List;
import java.util.ArrayList;

//Path("/")
public class FruitService {
/*    @GET
    @Path("/fruits")
    @Produces(MediaType.APPLICATION_JSON)
    private List<Fruit> getFruitsFromFile() {
        String fruitJson = readJsonFruitFile();
        return buildListFromJson(fruitJson);
    }


    private String readJsonFruitFile() {
        try {
         Path path = FileSystems.getDefault().getPath("fruit.json");
            return new String(Files.readAllBytes(path));
        } catch (IOException ioe) {
            return "[]";
        }
    }

    private List<Fruit> buildListFromJson(String fruitJson) {
        final TypeToken<List<Fruit>> token = new TypeToken<List<Fruit>>() {
        };
        final Type type = token.getType();
        final Gson gson = new Gson();
        return gson.fromJson(fruitJson, type);
    }*/
}
