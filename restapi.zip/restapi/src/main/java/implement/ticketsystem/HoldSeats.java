package implement.ticketsystem;

public class HoldSeats {
    
    public String email;
    public int selectSeat;
    
    public void setEmail(String _email) {
        email = _email;
    }

    public void setSelectSeat(int _selectSeat) {
        selectSeat = _selectSeat;
    }

    public HoldSeats setHold() {
        return this;
    }

    public String getEmail() {
        return email;
    }

    public int getSelectSeat() {
        return selectSeat;
    }
}
