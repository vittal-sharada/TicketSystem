package implement.ticketsystem;

import java.util.ArrayList;
import java.util.HashSet;

public class Tickets {

    // ArrayList <Integer> allTickets = new ArrayList<Integer>(289);
  //  HashSet<String> allTickets = new HashSet<String>(289);
   // HashSet<String> holdTickets = new HashSet<String>(289);
   // HashSet<String> reserveTickets = new HashSet<String>(289);


    public int _max;
    public int _response;
    public int _hold;
    public int _reserve;

    public int getResponse() {
        return _response;
    }

    public void setResponse(int response) {
        _response = response;
    }


    public int getMax() {
        return _max;
    }


    public void setMax(int max) {
        _max = max;
       // ArrayList<Integer> subList = (ArrayList<Integer>) allTickets.subList(0, max);
       // subList.clear();
       // System.out.println("max size= " + allTickets.size());
    }

    public int getHold() {
        return _hold;
    }

    public void setHold(int hold) {
        _hold = hold;
    }

    public int getReserve() {
        return _reserve;
    }

    public void setReserve(int reserve) {
       _reserve = reserve;
    }


    public int viewseats() {
        return (_max -(_hold + _reserve));
    }
}
