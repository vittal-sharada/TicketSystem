package implement.ticketsystem;

public class ReserveSeats {

    public String resConfirmation;
    public String reserveid;
    public int holdid;
    public String reserveEmail;

    public void setHoldid(int _holdid) {
        holdid = _holdid;
    }
    public void setReserveEmail(String _reserveEmail) {
        reserveEmail = _reserveEmail;
    }

    public String getResConfirmation() {
        resConfirmation = holdid +"-"+reserveEmail;
        return resConfirmation;
    }



}
