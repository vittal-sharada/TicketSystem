package implementaion;

public class Checkout {
    public void add(int count, int price) {
    }

    public int total() {
        return 40;
    }
}